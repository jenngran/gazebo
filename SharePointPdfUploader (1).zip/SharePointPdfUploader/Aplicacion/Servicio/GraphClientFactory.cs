
using Azure.Identity;
using Microsoft.Graph;
using Microsoft.Extensions.Options;
using BPE.SharePointPdfUploader.Dominio.Modelo;

namespace BPE.SharePointPdfUploader.Aplicacion.Servicio;

public class GraphClientFactory
{
    private readonly GraphOptions _options;

    public GraphClientFactory(IOptions<GraphOptions> options)
    {
        _options = options.Value;
    }

    public GraphServiceClient Create()
    {
        var credential = new ClientSecretCredential(_options.TenantId, _options.ClientId, _options.ClientSecret);
        var scopes = new[] { "https://graph.microsoft.com/.default" };
        return new GraphServiceClient(credential, scopes);
    }
}
