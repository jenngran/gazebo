
using BPE.SharePointPdfUploader.Dominio.Modelo;

namespace BPE.SharePointPdfUploader.Aplicacion.Servicio;

public interface ISharePointUploader
{
    Task<string> UploadPdfAsync(Stream fileStream, string fileName, PdfMetadata metadata, string? folderPathOverride = null, CancellationToken cancellationToken = default);
}
