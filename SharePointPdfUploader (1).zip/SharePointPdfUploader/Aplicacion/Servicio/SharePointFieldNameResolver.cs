﻿using Microsoft.Graph;
//using Microsoft.Graph.Modelo;

namespace BPE.SharePointPdfUploader.Aplicacion.Servicio;

public static class SharePointFieldNameResolver
{
    public static async Task<Dictionary<string, string>> GetInternalColumnNamesAsync(
        GraphServiceClient client, string driveId, CancellationToken ct)
    {
        var list = await client.Drives[driveId].List.GetAsync(cancellationToken: ct)
                   ?? throw new InvalidOperationException("No se pudo resolver la lista asociada a la biblioteca");

        var cols = await client.Sites[list.ParentReference!.SiteId!]
                              .Lists[list.Id!]
                              .Columns
                              .GetAsync(cancellationToken: ct)
                   ?? throw new InvalidOperationException("No se pudieron obtener las columnas de la biblioteca");

        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var c in cols.Value!)
        {
            if (!string.IsNullOrWhiteSpace(c.DisplayName))
                map[Normalize(c.DisplayName!)] = c.Name!;
            if (!string.IsNullOrWhiteSpace(c.Name))
                map[Normalize(c.Name!)] = c.Name!;
        }
        return map;
    }

    public static string Normalize(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return string.Empty;
        s = s.Trim();
        s = s.Replace("_", "").Replace("-", "").Replace(" ", "");
        s = s.Replace("á", "a").Replace("é", "e").Replace("í", "i").Replace("ó", "o").Replace("ú", "u").Replace("ñ", "n")
             .Replace("Á", "A").Replace("É", "E").Replace("Í", "I").Replace("Ó", "O").Replace("Ú", "U").Replace("Ñ", "N");
        return s;
    }
}