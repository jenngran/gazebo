
using Microsoft.Extensions.Options;
using Microsoft.Graph;
using Microsoft.Graph.Models; // Para DriveItem, FieldValueSet, etc.
using Microsoft.Graph.Models.ODataErrors;

using Microsoft.Kiota.Abstractions;

using System.Net.Http.Headers;
using System.Text.Json;
using DriveUpload = Microsoft.Graph.Drives.Item.Items.Item.CreateUploadSession;
using BPE.SharePointPdfUploader.Dominio.Modelo;

namespace BPE.SharePointPdfUploader.Aplicacion.Servicio;

public class SharePointUploader : ISharePointUploader
{
    private readonly GraphClientFactory _clientFactory;
    private readonly GraphOptions _options;
    private readonly HttpClient _httpClient;

    public SharePointUploader(GraphClientFactory clientFactory, IOptions<GraphOptions> options)
    {
        _clientFactory = clientFactory;
        _options = options.Value;
        _httpClient = new HttpClient();
    }

    public async Task<string> UploadPdfAsync(Stream fileStream, string fileName, PdfMetadata metadata, string? folderPathOverride = null, CancellationToken cancellationToken = default)
    {
        string? itemId = null;
        try
        {
            var client = _clientFactory.Create();

        // 1) Resolve site
        //var site = await client.Sites[_options.SiteHostname].Sites[_options.SitePath].GetAsync(cancellationToken: cancellationToken)
        //           ?? throw new InvalidOperationException("No se pudo resolver el sitio de SharePoint");
       
        var site = await client
            .Sites[$"{_options.SiteHostname}:/{_options.SitePath}"]
            .GetAsync(cancellationToken: cancellationToken)
            ?? throw new InvalidOperationException("No se pudo resolver el sitio por ruta");

        Console.WriteLine($"Site resolved: {site?.Id} | {site?.WebUrl}");
        // 2) Find drive (document library) by name
        var drives = await client.Sites[site.Id].Drives.GetAsync(cancellationToken: cancellationToken);
        var drive = drives?.Value?.FirstOrDefault(d => string.Equals(d.Name, _options.LibraryName, StringComparison.OrdinalIgnoreCase))
                    ?? throw new InvalidOperationException($"No se encontró la biblioteca '{_options.LibraryName}' en el sitio");

        // 3) Build target path
        var folderPath = string.IsNullOrWhiteSpace(folderPathOverride) ? _options.DefaultFolderPath : folderPathOverride!;
        var parentFolder = await EnsureFolderByPathAsync(client, drive.Id, folderPath, cancellationToken);

        

        // Ensure folder exists (optional). We'll just attempt upload by path; Graph will fail if it doesn't exist.

        // 4) Always use upload session for robustness (works for any size)
        var uploadPath = string.IsNullOrEmpty(folderPath) ? fileName : $"{folderPath}/{fileName}";

        // Create upload session
        //var createSessionBody = new DriveUpload.CreateUploadSessionPostRequestBody
        //{
        //    Item = new DriveItemUploadableProperties
        //    {
        //        Name = fileName,
        //        AdditionalData = new Dictionary<string, object>
        //        {
        //            { "@microsoft.graph.conflictBehavior", "replace" },
        //        },
        //    },
        //};

        var createSessionBody = new DriveUpload.CreateUploadSessionPostRequestBody
        {
                Item = new DriveItemUploadableProperties
                {
                    AdditionalData = new Dictionary<string, object>
                    {
                        { "@microsoft.graph.conflictBehavior", "replace" },
                    },
                },
        };

            var uploadSession = await client
            .Drives[drive.Id]
            .Items[parentFolder.Id]                 
            .ItemWithPath(fileName)
            .CreateUploadSession
            .PostAsync(createSessionBody, cancellationToken: cancellationToken)
             ?? throw new InvalidOperationException("No se pudo crear la sesión de carga");



        var uploadUrl = uploadSession.UploadUrl ?? throw new InvalidOperationException("UploadUrl vacío en la sesión de carga");

            // Upload in chunks multiples of 320 KiB
            const int chunkSize = 5 * 1024 * 1024; // 5 MB (múltiplo de 320 KiB)
            byte[] buffer = new byte[chunkSize];

            long fileSize = 0;
            if (fileStream.CanSeek)
            {
                fileSize = fileStream.Length;
                fileStream.Position = 0;
            }
            else
            {
                // Buffer to memory to know size
                using var ms = new MemoryStream();
                await fileStream.CopyToAsync(ms, cancellationToken);
                ms.Position = 0;
                fileStream = ms;
                fileSize = ms.Length;
            }

            long uploaded = 0;
            

            while (uploaded < fileSize)
            {
                var toRead = (int)Math.Min(chunkSize, fileSize - uploaded);
                var bytesRead = await fileStream.ReadAsync(buffer, 0, toRead, cancellationToken);
                if (bytesRead == 0) break;

                var from = uploaded;                       // inicio (0-based)
                var to = uploaded + bytesRead - 1;       // fin (INCLUSIVO)
                if (to >= fileSize) to = fileSize - 1;     // clamp por seguridad

                using var content = new ByteArrayContent(buffer, 0, bytesRead);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                content.Headers.ContentRange = new ContentRangeHeaderValue(from, to, fileSize); // <-- header correcto

                using var response = await _httpClient.PutAsync(uploadUrl, content, cancellationToken);
                if (!response.IsSuccessStatusCode)
                {
                    var err = await response.Content.ReadAsStringAsync(cancellationToken);
                    throw new InvalidOperationException($"Error al subir chunk: {response.StatusCode} {err}");
                }

                // Si el último chunk ya "commitió" el archivo, el body trae el DriveItem
                if (response.StatusCode == System.Net.HttpStatusCode.Created ||
                    response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var contentText = await response.Content.ReadAsStringAsync(cancellationToken);
                    try
                    {
                        using var doc = JsonDocument.Parse(contentText);
                        if (doc.RootElement.TryGetProperty("id", out var idProp))
                        {
                            itemId = idProp.GetString();
                        }
                    }
                    catch
                    {
                        // Ignorar parseo si no es la respuesta final
                    }
                }

                uploaded += bytesRead;
            }

            if (string.IsNullOrEmpty(itemId))
        {
            // Fallback: resolve by path
            var created = await client.Drives[drive.Id].Root.ItemWithPath(uploadPath).GetAsync(cancellationToken: cancellationToken);
            itemId = created?.Id ?? throw new InvalidOperationException("No se pudo obtener el ID del archivo subido");
        }

            // 1) Resolver la lista (biblioteca) y el listItem asociado al archivo
            var list = await client.Drives[drive.Id!].List.GetAsync(cancellationToken: cancellationToken)
                ?? throw new InvalidOperationException("No se pudo resolver la List asociada al Drive");

            var siteId = list.ParentReference?.SiteId
                ?? throw new InvalidOperationException("No se pudo resolver el SiteId de la List");

            var li = await client.Drives[drive.Id!].Items[itemId].ListItem.GetAsync(cancellationToken: cancellationToken)
                ?? throw new InvalidOperationException("No se pudo resolver el ListItem asociado al DriveItem");


            var columnMap = await GetInternalColumnNamesAsync(client, drive.Id!, cancellationToken);
            string ResolveInternal(params string[] candidates)
            {
                foreach (var cand in candidates)
                {
                    if (string.IsNullOrWhiteSpace(cand)) continue;
                    var key = Normalize(cand);
                    if (columnMap.TryGetValue(key, out var internalName))
                        return internalName;
                }
                throw new InvalidOperationException($"No se encontró el nombre interno para: {string.Join("/", candidates)}");
            }

            var tipoDocumentoInt = ResolveInternal("tipoDocumento", "Tipo Documento", "TipoDocumento");
            var emiteInt = ResolveInternal("Emite");
            var fechaEmisionInt = ResolveInternal("Fecha Emisión", "FechaEmision", "Fecha de Emisión");
            var descripcionInt = ResolveInternal("Descripción", "Descripcion");
            var decretoInt = ResolveInternal("Decreto");

            var fieldPayload = new Dictionary<string, object?>
            {
                { tipoDocumentoInt, metadata.TipoDocumento },
                { emiteInt,         metadata.Emite },
                { fechaEmisionInt,  metadata.FechaEmision.ToString("yyyy-MM-dd") },
                { descripcionInt,   metadata.Descripcion },
                { decretoInt,       metadata.Decreto }
            };

    //        var probe = await client.Sites[siteId].Lists[list.Id].Items[li.Id]
    //.GetAsync(rc => rc.QueryParameters.Expand = new[] { "fields($select=*)" }, cancellationToken);
    //        Console.WriteLine(JsonSerializer.Serialize(probe.Fields.AdditionalData, new JsonSerializerOptions { WriteIndented = true }));

            // 2) Parchear por la ruta de sitios/listas usando el **ID del ListItem**
            await client.Sites[siteId]
                .Lists[list.Id]
                .Items[li.Id]              // Ojo: este es el ID del ListItem (no el del DriveItem)
                .Fields
                .PatchAsync(
                    new FieldValueSet { AdditionalData = fieldPayload },
                    cancellationToken: cancellationToken
                );

            // 5) Resolver listId (biblioteca) y listItemId del archivo recién subido
            //var list = await client.Drives[drive.Id].List.GetAsync(cancellationToken: cancellationToken)
            //           ?? throw new InvalidOperationException("No se pudo resolver la List (biblioteca) asociada al Drive");

            //var li = await client.Drives[drive.Id].Items[itemId].ListItem.GetAsync(cancellationToken: cancellationToken)
            //         ?? throw new InvalidOperationException("No se pudo resolver el ListItem asociado al DriveItem");

            // 6) Preparar payload de campos
            //var fieldPayload = new Dictionary<string, object?>
            //{
            //    { _options.Field_TipoDocumento, metadata.TipoDocumento },
            //    { _options.Field_Emite,         metadata.Emite },
            //    { _options.Field_FechaEmision,  metadata.FechaEmision.ToString("yyyy-MM-dd") },
            //    { _options.Field_Descripcion,   metadata.Descripcion },
            //    { _options.Field_Decreto,       metadata.Decreto }
            //};


            // 7) Parchear campos vía /sites/{siteId}/lists/{listId}/items/{itemId}/fields
            //await client.Sites[site.Id]
            //       .Lists[list.Id]
            //       .Items[li.Id]
            //       .Fields
            //       .PatchAsync(new FieldValueSet { AdditionalData = fieldPayload },
            //                   cancellationToken: cancellationToken);

            // 5) Resolver nombres internos de columnas y parchear campos
            

            // Parchea los campos de metadata del item directamente por el drive
            //await client.Drives[drive.Id!]
            //    .Items[itemId]
            //    .ListItem
            //    .Fields
            //    .PatchAsync(
            //        new FieldValueSet { AdditionalData = fieldPayload },
            //        cancellationToken: cancellationToken
            //    );

            return itemId!;
        }
        //catch (ODataError ex)
        //{
        //    Console.WriteLine($"Error uploading: {ex.Error?.Message}");
        //    return itemId!;
        //}

        catch (ApiException ex)
        {
            // Si el cuerpo trae ODataError, ex.Message incluye el detalle.
            Console.WriteLine($"Error Graph: {ex.Message} (HTTP {(int?)ex.ResponseStatusCode})");
            throw; // o retorna, como prefieras
        }

    }

    private static async Task<Dictionary<string, string>> GetInternalColumnNamesAsync(
        GraphServiceClient client, string driveId, CancellationToken ct)
    {
        var list = await client.Drives[driveId].List.GetAsync(cancellationToken: ct);
        if (list == null || list.ParentReference?.SiteId == null)
            throw new InvalidOperationException("No se pudo resolver la lista asociada al drive");

        var columns = await client.Sites[list.ParentReference.SiteId]
                                  .Lists[list.Id]
                                  .Columns
                                  .GetAsync(cancellationToken: ct);

        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (columns?.Value != null)
        {
            foreach (var c in columns.Value)
            {
                if (!string.IsNullOrWhiteSpace(c.DisplayName))
                    map[Normalize(c.DisplayName)] = c.Name!;
                if (!string.IsNullOrWhiteSpace(c.Name))
                    map[Normalize(c.Name)] = c.Name!;
            }
        }
        return map;
    }

    private static string Normalize(string s)
    {
        if (string.IsNullOrEmpty(s)) return string.Empty;
        string t = s.Trim();
        t = t.Replace(" ", "").Replace("_", "").Replace("-", "");
        t = t.Replace("á", "a").Replace("é", "e").Replace("í", "i").Replace("ó", "o").Replace("ú", "u").Replace("ñ", "n");
        t = t.Replace("Á", "A").Replace("É", "E").Replace("Í", "I").Replace("Ó", "O").Replace("Ú", "U").Replace("Ñ", "N");
        return t;
    }
    private static async Task<DriveItem> EnsureFolderByPathAsync(GraphServiceClient client, string driveId, string? folderPath, CancellationToken ct)
    {
        folderPath = (folderPath ?? string.Empty).Trim().Trim('/');
        if (string.IsNullOrEmpty(folderPath))
        {
            var root = await client.Drives[driveId].Items["root"].GetAsync(cancellationToken: ct);
            return root!;
        }

        try
        {
            var existing = await client.Drives[driveId].Items["root"].ItemWithPath(folderPath).GetAsync(cancellationToken: ct);
            if (existing != null && existing.Folder != null) return existing;
        }
        catch { }

        var segments = folderPath.Split('/', StringSplitOptions.RemoveEmptyEntries);
        string currentPath = string.Empty;
        var parent = await client.Drives[driveId].Items["root"].GetAsync(cancellationToken: ct);

        foreach (var seg in segments)
        {
            currentPath = string.IsNullOrEmpty(currentPath) ? seg : $"{currentPath}/{seg}";
            DriveItem? curr = null;
            try
            {
                curr = await client.Drives[driveId].Items["root"].ItemWithPath(currentPath).GetAsync(cancellationToken: ct);
            }
            catch
            {
                var newFolder = new DriveItem
                {
                    Name = seg,
                    Folder = new Folder(),
                    AdditionalData = new Dictionary<string, object> { { "@microsoft.graph.conflictBehavior", "replace" } }
                };
                curr = await client.Drives[driveId].Items[parent!.Id].Children.PostAsync(newFolder, cancellationToken: ct);
            }
            parent = curr!;
        }

        return parent!;
    }
}
