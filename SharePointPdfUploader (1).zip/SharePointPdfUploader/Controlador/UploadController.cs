
using Microsoft.AspNetCore.Mvc;
using BPE.SharePointPdfUploader.Dominio.Modelo;
using BPE.SharePointPdfUploader.Aplicacion.Servicio;

namespace BPE.SharePointPdfUploader.Controlador;

[ApiController]
[Route("api/[controller]")]
public class UploadController : ControllerBase
{
    private readonly ISharePointUploader _uploader;

    public UploadController(ISharePointUploader uploader)
    {
        _uploader = uploader;
    }

    /// <summary>
    /// Carga un archivo PDF a SharePoint con sus metadatos.
    /// </summary>
    /// <remarks>
    /// Envía multipart/form-data con los campos: File, TipoDocumento, Emite, FechaEmision (yyyy-MM-dd), Descripcion, Decreto, FolderPath (opcional)
    /// </remarks>
    [HttpPost("upload-pdf")]
    [Consumes("multipart/form-data")]
    public async Task<IActionResult> UploadPdfWithMetadata([FromForm] UploadPdfRequest request, CancellationToken ct)
    {
        if (request.File == null || request.File.Length == 0)
            return BadRequest("El archivo es obligatorio.");

        if (!string.Equals(Path.GetExtension(request.File.FileName), ".pdf", StringComparison.OrdinalIgnoreCase))
            return BadRequest("Solo se permite subir archivos PDF (.pdf)");

        var metadata = new PdfMetadata
        {
            TipoDocumento = request.TipoDocumento,
            Emite = request.Emite,
            FechaEmision = request.FechaEmision,
            Descripcion = request.Descripcion,
            Decreto = request.Decreto
        };

        using var stream = request.File.OpenReadStream();
        var itemId = await _uploader.UploadPdfAsync(stream, request.File.FileName, metadata, request.FolderPath, ct);

        return Ok(new { itemId, message = "Cargado correctamente" });
    }
}
