namespace BPE.SharePointPdfUploader.Dominio.Modelo;

public class GraphOptions
{
    public string TenantId { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string ClientSecret { get; set; } = string.Empty;

    public string SiteHostname { get; set; } = string.Empty; // e.g., pacificobp.sharepoint.com
    public string SitePath { get; set; } = string.Empty;     // e.g., sites/DepartamentalAdministrativoTI
    public string LibraryName { get; set; } = string.Empty;  // e.g., Documentos Legales
    public string DefaultFolderPath { get; set; } = string.Empty; // e.g., 1. Marco Normativo Externo/1.5. Presidencia de la República

    // Optional: allow overriding field names if internal names differ
    public string Field_TipoDocumento { get; set; } = "tipoDocumento";
    public string Field_Emite { get; set; } = "Emite";
    public string Field_FechaEmision { get; set; } = "FechaEmision";
    public string Field_Descripcion { get; set; } = "Descripcion";
    public string Field_Decreto { get; set; } = "Decreto";
}
