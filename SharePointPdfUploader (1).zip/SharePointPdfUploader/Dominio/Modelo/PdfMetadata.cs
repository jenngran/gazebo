namespace BPE.SharePointPdfUploader.Dominio.Modelo;

public class PdfMetadata
{
    public string TipoDocumento { get; set; } = string.Empty;
    public string Emite { get; set; } = string.Empty;
    public DateTime FechaEmision { get; set; }
    public string Descripcion { get; set; }
    public string Decreto { get; set; }
}
