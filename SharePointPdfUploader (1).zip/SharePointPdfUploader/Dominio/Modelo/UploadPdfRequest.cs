
using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace BPE.SharePointPdfUploader.Dominio.Modelo;

public class UploadPdfRequest
{
    [Required]
    public IFormFile File { get; set; } = default!;

    // Si no se envía, usaremos la ruta por defecto de configuración
    public string FolderPath { get; set; }

    // Metadatos requeridos por el usuario
    [Required]
    public string TipoDocumento { get; set; } = string.Empty;

    [Required]
    public string Emite { get; set; } = string.Empty;

    [Required]
    [DataType(DataType.Date)]
    public DateTime FechaEmision { get; set; }

    public string Descripcion { get; set; }
    public string Decreto { get; set; }
}
