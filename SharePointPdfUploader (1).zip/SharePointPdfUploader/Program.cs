
using Microsoft.AspNetCore.Http.Features;
using Microsoft.OpenApi.Models;
//using SharePointPdfUploader.Options;
using BPE.SharePointPdfUploader.Aplicacion.Servicio;
using BPE.SharePointPdfUploader.Dominio.Modelo;

var builder = WebApplication.CreateBuilder(args);

// Options
builder.Services.Configure<GraphOptions>(builder.Configuration.GetSection("Graph"));

// Services
builder.Services.AddSingleton<GraphClientFactory>();
builder.Services.AddScoped<ISharePointUploader, SharePointUploader>();

builder.Services.AddControllers();

builder.Services.Configure<FormOptions>(o =>
{
    // 100 MB upload limit (adjust as needed)
    o.MultipartBodyLengthLimit = 100 * 1024 * 1024;
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "SharePoint PDF Uploader API",
        Version = "v1",
        Description = "API para cargar PDFs y metadatos a una biblioteca de SharePoint Online usando Microsoft Graph"
    });
});

var app = builder.Build();

app.UseHttpsRedirection();

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Uploader v1");
});

app.MapControllers();

app.Run();
