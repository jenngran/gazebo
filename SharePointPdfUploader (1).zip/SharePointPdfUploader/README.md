
# SharePoint PDF Uploader API (.NET 8)

API para cargar archivos **PDF** a una **biblioteca de documentos de SharePoint Online** y actualizar sus **metadatos** personalizados usando **Microsoft Graph**.

## 🚀 Características
- Endpoint `POST /api/upload/upload-pdf` (Swagger incluido)
- Recibe `multipart/form-data` con `IFormFile` y campos de metadatos
- Sube el archivo a una **ruta específica** dentro de la biblioteca
- Actualiza los campos: `tipoDocumento`, `Emite`, `FechaEmision`, `Descripcion`, `Decreto`
- Usa **Client Credentials** con `Azure AD` (app registration)
- Maneja uploads grandes con **Upload Session** (chunked)

## ✅ Requisitos
- .NET 8 SDK
- App Registration en Azure AD con **Application Permissions** en Microsoft Graph:
  - `Sites.ReadWrite.All` (o **Sites.Selected** + acceso al sitio)
  - Alternativamente `Files.ReadWrite.All` también funciona para contenido
- Conceder **admin consent**

## 🔧 Configuración
Edita `appsettings.json`:
```json
{
  "Graph": {
    "TenantId": "<tu-tenant-id>",
    "ClientId": "<tu-client-id>",
    "ClientSecret": "<tu-client-secret>",
    "SiteHostname": "pacificobp.sharepoint.com",
    "SitePath": "sites/DepartamentalAdministrativoTI",
    "LibraryName": "Documentos Legales",
    "DefaultFolderPath": "1. Marco Normativo Externo/1.5. Presidencia de la República",
    "Field_TipoDocumento": "tipoDocumento",
    "Field_Emite": "Emite",
    "Field_FechaEmision": "FechaEmision",
    "Field_Descripcion": "Descripcion",
    "Field_Decreto": "Decreto"
  }
}
```
> ⚠️ **Importante**: Verifica los **nombres internos** de los campos en SharePoint (pueden diferir de los títulos). En la biblioteca → **Settings** → **List settings** → **Column** → mira el parámetro `Field` en la URL.

## ▶️ Ejecución
```bash
# Restaurar y construir
 dotnet restore
 dotnet build

# Ejecutar
 dotnet run
```
Abre Swagger en `https://localhost:5001/swagger` o `http://localhost:5000/swagger`.

## 🧪 Probar el endpoint
- `POST /api/upload/upload-pdf`
- **Content-Type**: `multipart/form-data`
- Campos:
  - `File`: (selecciona un PDF)
  - `TipoDocumento`: p. ej. `Decreto`
  - `Emite`: p. ej. `Presidencia de la República`
  - `FechaEmision`: `2025-10-01`
  - `Descripcion`: texto
  - `Decreto`: texto
  - `FolderPath` (opcional): si omites, usa `DefaultFolderPath` de configuración

## 🧱 Estructura del proyecto
```
SharePointPdfUploader/
├─ Controllers/
│  └─ UploadController.cs
├─ Models/
│  ├─ UploadPdfRequest.cs
│  └─ PdfMetadata.cs
├─ Options/
│  └─ GraphOptions.cs
├─ Services/
│  ├─ GraphClientFactory.cs
│  ├─ ISharePointUploader.cs
│  └─ SharePointUploader.cs
├─ appsettings.json
├─ Program.cs
├─ SharePointPdfUploader.csproj
└─ README.md
```

## 🔒 Permisos & Consideraciones
- Este proyecto usa **Upload Session** de Graph y luego **PATCH** a `listItem/fields` para escribir metadatos.
- Asegúrate de que tu aplicación tenga permisos y que el **admin consent** se haya otorgado.
- Si usas `Sites.Selected`, otorga acceso al sitio con `Add-SPOGraphPermission` o desde el portal.

## 📚 Referencias
- Carga en trozos con **createUploadSession** (Graph)  
  https://learn.microsoft.com/graph/api/driveitem-createuploadsession  
- Actualizar campos de un elemento (PATCH a `listItem/fields`)  
  https://learn.microsoft.com/graph/api/driveitem-update (ver nota y relación con `listItem`)  

## 🧰 Troubleshooting
- **Swagger no muestra input de archivo**: Asegúrate de `[Consumes("multipart/form-data")]` y `[FromForm]` en el modelo del endpoint.  
- **Campo de SharePoint no se actualiza**: confirma el **nombre interno** y el **tipo** (fechas deben ir como `yyyy-MM-dd`).  
- **403 Forbidden**: faltan permisos o falta el **admin consent**.
- **404 en ruta**: valida `LibraryName` y `FolderPath`. La ruta es relativa a la biblioteca.

---
Made with ❤️ for uploads a SharePoint.
