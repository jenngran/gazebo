# tb3_dataset_tools

Herramientas ROS 2 para **capturar dataset** de **Aprendizaje por Refuerzo** (transiciones s,a,r,s',done) y **guardar imágenes RGB/Depth** con CameraInfo, usando **TurtleBot3** en **Gazebo**.

## Requisitos
- ROS 2 (Foxy/Humble/Iron)
- Gazebo Classic (para turtlebot3_gazebo)
- `vision_opencv` (cv_bridge) – para el image logger
- `image_transport`

## Instalación
```bash
# En tu overlay de ROS 2
cd ~/ros2_ws/src
# Copia este paquete aquí
# (si descargaste un ZIP, descomprímelo y colócalo dentro de src)
colcon build --packages-select tb3_dataset_tools
source ~/ros2_ws/install/setup.bash
```

## Ejecución (ejemplo con waffle_pi y RealSense simulado)
```bash
# Lanzar Gazebo (GUI)
ros2 launch turtlebot3_gazebo turtlebot3_world.launch.py
# o solo servidor para más FPS
# gzserver $(ros2 pkg prefix turtlebot3_gazebo)/share/turtlebot3_gazebo/worlds/turtlebot3_world.world &

# Lanzar ambos nodos con parámetros por defecto (salida en ./dataset)
ros2 launch tb3_dataset_tools dataset_logging.launch.py
```

### Parámetros clave
- **rl_logger_ros2**:
  - `out_dir` (default: `dataset`)
  - `use_internal_policy` (true/false)
  - `hz` (10), `scan_stride` (6-8), `collision_range` (0.12), `max_steps_per_ep` (600)
  - `goal_x`, `goal_y`, `goal_radius` (0.30)
  - `randomize_goal` + `goal_bounds` para metas aleatorias
- **image_logger_ros2**:
  - `out_dir` (compartido con RL)
  - `rgb_topic`, `depth_topic`, `camera_info_topic`
  - `save_depth` (bool), `save_rate_hz` (3-5), `jpeg_quality` (95)

## Estructura de salida
```
dataset/
  transitions.jsonl
  episodes.jsonl
  meta.yaml
  rgb/
  depth/       # si save_depth=true
  camera_info.yaml
  classes.txt  # copiado desde config/classes.txt
```

## Notas
- Usa `gzserver` para subir FPS.
- Asegúrate de que tu modelo tiene cámara (p.ej. `TURTLEBOT3_MODEL=waffle_pi`).
- Ajusta los tópicos de cámara en el launch si difieren.
