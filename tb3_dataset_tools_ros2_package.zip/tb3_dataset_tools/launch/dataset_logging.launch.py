from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
import os

def generate_launch_description():
    out_dir = LaunchConfiguration('out_dir')
    use_internal_policy = LaunchConfiguration('use_internal_policy')
    save_depth = LaunchConfiguration('save_depth')
    save_rate_hz = LaunchConfiguration('save_rate_hz')

    rgb_topic = LaunchConfiguration('rgb_topic')
    depth_topic = LaunchConfiguration('depth_topic')
    camera_info_topic = LaunchConfiguration('camera_info_topic')

    return LaunchDescription([
        DeclareLaunchArgument('out_dir', default_value='dataset'),
        DeclareLaunchArgument('use_internal_policy', default_value='true'),
        DeclareLaunchArgument('save_depth', default_value='true'),
        DeclareLaunchArgument('save_rate_hz', default_value='5.0'),
        # Tópicos por defecto (waffle_pi RealSense sim)
        DeclareLaunchArgument('rgb_topic', default_value='/camera/color/image_raw'),
        DeclareLaunchArgument('depth_topic', default_value='/camera/depth/image_raw'),
        DeclareLaunchArgument('camera_info_topic', default_value='/camera/color/camera_info'),

        Node(
            package='tb3_dataset_tools',
            executable='rl_logger_ros2',
            name='rl_logger_ros2',
            output='screen',
            parameters=[{
                'out_dir': out_dir,
                'use_internal_policy': use_internal_policy,
                'hz': 10,
                'scan_stride': 6,
                'collision_range': 0.12,
                'max_steps_per_ep': 600,
                'goal_x': 2.0,
                'goal_y': 0.0,
                'goal_radius': 0.30,
                'randomize_goal': False,
                'goal_bounds': [-2.0, 2.0, -2.0, 2.0]
            }]
        ),
        Node(
            package='tb3_dataset_tools',
            executable='image_logger_ros2',
            name='image_logger_ros2',
            output='screen',
            parameters=[{
                'out_dir': out_dir,
                'rgb_topic': rgb_topic,
                'depth_topic': depth_topic,
                'camera_info_topic': camera_info_topic,
                'save_depth': save_depth,
                'save_rate_hz': save_rate_hz,
                'jpeg_quality': 95
            }]
        )
    ])
