#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROS2 Image Logger: guarda RGB (y opcional Depth) + CameraInfo
"""
import os
from datetime import datetime
import numpy as np
import cv2

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

from sensor_msgs.msg import Image, CameraInfo
from cv_bridge import CvBridge

def ts_iso(sec, nsec):
    t = sec + nsec * 1e-9
    return datetime.utcfromtimestamp(t).strftime("%Y-%m-%dT%H-%M-%S.%f")[:-3]

class ImageLoggerROS2(Node):
    def __init__(self):
        super().__init__('image_logger_ros2')
        self.declare_parameter('out_dir', 'dataset')
        self.declare_parameter('rgb_topic', '/camera/color/image_raw')
        self.declare_parameter('depth_topic', '/camera/depth/image_raw')
        self.declare_parameter('camera_info_topic', '/camera/color/camera_info')
        self.declare_parameter('save_depth', False)
        self.declare_parameter('save_rate_hz', 5.0)
        self.declare_parameter('jpeg_quality', 95)

        self.out_dir = self.get_parameter('out_dir').value
        self.rgb_topic = self.get_parameter('rgb_topic').value
        self.depth_topic = self.get_parameter('depth_topic').value
        self.camera_info_topic = self.get_parameter('camera_info_topic').value
        self.save_depth = bool(self.get_parameter('save_depth').value)
        self.save_rate_hz = float(self.get_parameter('save_rate_hz').value)
        self.jpeg_quality = int(self.get_parameter('jpeg_quality').value)

        self.rgb_dir = os.path.join(self.out_dir, 'rgb')
        self.depth_dir = os.path.join(self.out_dir, 'depth')
        os.makedirs(self.out_dir, exist_ok=True)
        os.makedirs(self.rgb_dir, exist_ok=True)
        if self.save_depth:
            os.makedirs(self.depth_dir, exist_ok=True)

        self.caminfo_saved = False
        self.bridge = CvBridge()
        self.last_save_time = 0.0
        self.min_dt = 1.0 / max(0.1, self.save_rate_hz)

        qos_sensor = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT,
                                history=HistoryPolicy.KEEP_LAST, depth=10,
                                durability=DurabilityPolicy.VOLATILE)

        self.create_subscription(Image, self.rgb_topic, self.rgb_cb, qos_sensor)
        if self.save_depth:
            self.create_subscription(Image, self.depth_topic, self.depth_cb, qos_sensor)
        self.create_subscription(CameraInfo, self.camera_info_topic, self.caminfo_cb, qos_sensor)

        # copia classes.txt al dataset si existe en share
        try:
            import ament_index_python.packages as ament_pkgs
            pkg_share = ament_pkgs.get_package_share_directory('tb3_dataset_tools')
            classes_src = os.path.join(pkg_share, 'config', 'classes.txt')
            classes_dst = os.path.join(self.out_dir, 'classes.txt')
            if os.path.exists(classes_src) and not os.path.exists(classes_dst):
                with open(classes_src, 'rb') as fsrc, open(classes_dst, 'wb') as fdst:
                    fdst.write(fsrc.read())
        except Exception:
            pass

        self.get_logger().info(f"ImageLogger guardando en {self.out_dir}")
        self.get_logger().info(f"RGB: {self.rgb_topic} | Depth: {self.depth_topic} | CamInfo: {self.camera_info_topic}")

    def caminfo_cb(self, msg: CameraInfo):
        if self.caminfo_saved:
            return
        path = os.path.join(self.out_dir, 'camera_info.yaml')
        try:
            import yaml
            data = {
                'image_width': int(msg.width),
                'image_height': int(msg.height),
                'camera_matrix': {'rows': 3, 'cols': 3, 'data': list(msg.k)},
                'distortion_model': msg.distortion_model,
                'distortion_coefficients': {'rows': 1, 'cols': len(msg.d), 'data': list(msg.d)}
            }
            with open(path, 'w') as f:
                yaml.safe_dump(data, f, default_flow_style=False)
            self.caminfo_saved = True
            self.get_logger().info(f"camera_info.yaml guardado en {path}")
        except Exception as e:
            self.get_logger().warn(f"No se pudo guardar camera_info.yaml: {e}")

    def rgb_cb(self, msg: Image):
        now = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if (now - self.last_save_time) < self.min_dt:
            return
        self.last_save_time = now
        try:
            cv_img = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().warn(f"cv_bridge RGB: {e}")
            return
        name = ts_iso(msg.header.stamp.sec, msg.header.stamp.nanosec)
        path = os.path.join(self.rgb_dir, f"{name}.jpg")
        ok = cv2.imwrite(path, cv_img, [int(cv2.IMWRITE_JPEG_QUALITY), int(self.jpeg_quality)])
        if ok:
            self.get_logger().info(f"RGB guardada: {os.path.basename(path)}")

    def depth_cb(self, msg: Image):
        try:
            cv_depth = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')
            depth_mm = np.clip(cv_depth * 1000.0, 0, 65535).astype(np.uint16)
        except Exception as e:
            self.get_logger().warn(f"cv_bridge DEPTH: {e}")
            return
        name = ts_iso(msg.header.stamp.sec, msg.header.stamp.nanosec)
        path = os.path.join(self.depth_dir, f"{name}.png")
        ok = cv2.imwrite(path, depth_mm)
        if ok:
            self.get_logger().info(f"Depth guardada: {os.path.basename(path)}")

def main():
    rclpy.init()
    node = ImageLoggerROS2()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node(); rclpy.shutdown()

if __name__ == '__main__':
    main()
