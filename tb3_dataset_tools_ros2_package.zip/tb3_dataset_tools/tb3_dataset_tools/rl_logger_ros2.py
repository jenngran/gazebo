#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROS2 RL Logger para TurtleBot3 en Gazebo.
Registra transiciones (s, a, r, s', done) en JSONL.
"""
import os, json, math, time, random
from datetime import datetime
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist

def now_iso():
    return datetime.utcnow().strftime("%Y-%m-%dT%H-%M-%S.%f")[:-3] + "Z"

def sanitize_scan(ranges, rmax):
    arr = np.array(ranges, dtype=np.float32)
    arr[~np.isfinite(arr)] = rmax
    return arr

def yaw_from_quat(q):
    x, y, z, w = q.x, q.y, q.z, q.w
    siny_cosp = 2.0 * (w*z + x*y)
    cosy_cosp = 1.0 - 2.0 * (y*y + z*z)
    return math.atan2(siny_cosp, cosy_cosp)

def wrap_pi(a):
    while a >  math.pi: a -= 2*math.pi
    while a < -math.pi: a += 2*math.pi
    return a

class RLLoggerROS2(Node):
    def __init__(self):
        super().__init__('rl_logger_ros2')
        self.declare_parameter('out_dir', 'dataset')
        self.declare_parameter('goal_x', 2.0)
        self.declare_parameter('goal_y', 0.0)
        self.declare_parameter('goal_radius', 0.30)
        self.declare_parameter('scan_topic', '/scan')
        self.declare_parameter('odom_topic', '/odom')
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')
        self.declare_parameter('use_internal_policy', True)
        self.declare_parameter('hz', 10)
        self.declare_parameter('scan_stride', 6)
        self.declare_parameter('collision_range', 0.12)
        self.declare_parameter('max_steps_per_ep', 600)
        self.declare_parameter('lin_vel', 0.18)
        self.declare_parameter('ang_vel', 0.9)
        self.declare_parameter('randomize_goal', False)
        self.declare_parameter('goal_bounds', [-2.0, 2.0, -2.0, 2.0])

        self.out_dir = self.get_parameter('out_dir').value
        self.goal_x = float(self.get_parameter('goal_x').value)
        self.goal_y = float(self.get_parameter('goal_y').value)
        self.goal_radius = float(self.get_parameter('goal_radius').value)
        self.scan_topic = self.get_parameter('scan_topic').value
        self.odom_topic = self.get_parameter('odom_topic').value
        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value
        self.use_internal_policy = bool(self.get_parameter('use_internal_policy').value)
        self.hz = int(self.get_parameter('hz').value)
        self.scan_stride = max(1, int(self.get_parameter('scan_stride').value))
        self.collision_range = float(self.get_parameter('collision_range').value)
        self.max_steps_per_ep = int(self.get_parameter('max_steps_per_ep').value)
        self.lin_vel = float(self.get_parameter('lin_vel').value)
        self.ang_vel = float(self.get_parameter('ang_vel').value)
        self.randomize_goal = bool(self.get_parameter('randomize_goal').value)
        self.goal_bounds = [float(x) for x in self.get_parameter('goal_bounds').value]

        os.makedirs(self.out_dir, exist_ok=True)
        self.path_transitions = os.path.join(self.out_dir, 'transitions.jsonl')
        self.path_episodes = os.path.join(self.out_dir, 'episodes.jsonl')
        self.path_meta = os.path.join(self.out_dir, 'meta.yaml')
        if not os.path.exists(self.path_meta):
            with open(self.path_meta, 'w') as f:
                f.write(f"goal: [{self.goal_x}, {self.goal_y}]\n")
                f.write(f"goal_radius: {self.goal_radius}\n")
                f.write(f"hz: {self.hz}\nscan_stride: {self.scan_stride}\n")
                f.write(f"collision_range: {self.collision_range}\n")
                f.write(f"max_steps_per_ep: {self.max_steps_per_ep}\n")

        self.last_scan = None
        self.scan_range_max = 3.5
        self.last_odom = None
        self.episode, self.step, self.ep_rewards = 1, 0, 0.0
        self.prev_obs = None

        qos_sensor = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT,
                                history=HistoryPolicy.KEEP_LAST, depth=10,
                                durability=DurabilityPolicy.VOLATILE)
        qos_default = QoSProfile(depth=10)

        self.create_subscription(LaserScan, self.scan_topic, self.scan_cb, qos_sensor)
        self.create_subscription(Odometry, self.odom_topic, self.odom_cb, qos_default)
        self.pub_cmd = self.create_publisher(Twist, self.cmd_vel_topic, 10)
        self.timer = self.create_timer(1.0/float(self.hz), self.loop)
        self.get_logger().info(f"RLLoggerROS2 listo. Guardando en {self.out_dir}")

    def scan_cb(self, msg: LaserScan):
        self.scan_range_max = msg.range_max if np.isfinite(msg.range_max) else 3.5
        self.last_scan = sanitize_scan(msg.ranges, self.scan_range_max)

    def odom_cb(self, msg: Odometry):
        self.last_odom = msg

    def compute_obs(self):
        if self.last_scan is None or self.last_odom is None:
            return None
        scan = self.last_scan[::self.scan_stride]
        p = self.last_odom.pose.pose.position
        q = self.last_odom.pose.pose.orientation
        yaw = yaw_from_quat(q)
        dx = self.goal_x - p.x
        dy = self.goal_y - p.y
        rel_x =  math.cos(yaw)*dx + math.sin(yaw)*dy
        rel_y = -math.sin(yaw)*dx + math.cos(yaw)*dy
        goal_yaw = math.atan2(dy, dx)
        d_yaw = wrap_pi(goal_yaw - yaw)
        return {"scan": scan.astype(np.float32).tolist(),
                "rel_goal": [float(rel_x), float(rel_y), float(d_yaw)]}

    def select_action(self, obs):
        rel_x, rel_y, d_yaw = obs["rel_goal"]
        scan = np.array(obs["scan"], dtype=np.float32)
        c = len(scan)//2
        front = float(np.mean(scan[max(0, c-2):c+3])) if len(scan) >= 5 else float(scan[c])
        if abs(d_yaw) > 0.3:
            return 1 if d_yaw > 0 else 2
        if front < 0.35:
            return 1
        return 0

    def apply_action(self, a):
        twist = Twist()
        if a == 0:
            twist.linear.x = self.lin_vel
        elif a == 1:
            twist.angular.z = self.ang_vel
        elif a == 2:
            twist.angular.z = -self.ang_vel
        self.pub_cmd.publish(twist)

    def compute_reward_done(self, obs):
        rel_x, rel_y, _ = obs["rel_goal"]
        dist = math.hypot(rel_x, rel_y)
        scan = np.array(obs["scan"], dtype=np.float32)
        scan_min = float(np.min(scan)) if scan.size > 0 else 999.0
        collision = scan_min <= self.collision_range
        goal_reached = dist <= self.goal_radius
        reward, done = -0.01, False
        if goal_reached:
            reward += 1.0; done = True
        if collision:
            reward -= 1.0; done = True
        if self.step >= self.max_steps_per_ep:
            done = True
        info = {"collision": bool(collision), "goal_reached": bool(goal_reached), "dist": float(dist)}
        return reward, done, info

    def log_transition(self, obs, action, reward, done, next_obs, info):
        rec = {"episode": self.episode, "step": self.step, "t": now_iso(),
               "obs": obs, "action": {"discrete": int(action)}, "reward": float(reward),
               "done": bool(done), "next_obs": next_obs, "info": info}
        with open(self.path_transitions, 'a') as f:
            f.write(json.dumps(rec) + "\n")

    def log_episode(self):
        rec = {"episode": self.episode, "steps": self.step, "return": float(self.ep_rewards),
               "t_end": now_iso(), "goal": [self.goal_x, self.goal_y]}
        with open(self.path_episodes, 'a') as f:
            f.write(json.dumps(rec) + "\n")

    def stop_robot(self):
        self.pub_cmd.publish(Twist())

    def maybe_randomize_goal(self):
        if not self.randomize_goal:
            return
        min_x, max_x, min_y, max_y = self.goal_bounds
        self.goal_x = random.uniform(min_x, max_x)
        self.goal_y = random.uniform(min_y, max_y)
        self.get_logger().info(f"Nuevo objetivo: ({self.goal_x:.2f}, {self.goal_y:.2f})")

    def loop(self):
        if self.last_scan is None or self.last_odom is None:
            return
        cur_obs = self.compute_obs()
        if cur_obs is None:
            return
        if self.prev_obs is None:
            self.prev_obs = cur_obs
            return
        action = self.select_action(self.prev_obs) if self.use_internal_policy else 3
        if self.use_internal_policy:
            self.apply_action(action)
        next_obs = cur_obs
        reward, done, info = self.compute_reward_done(next_obs)
        self.step += 1
        self.ep_rewards += reward
        self.log_transition(self.prev_obs, action, reward, done, next_obs, info)
        self.prev_obs = next_obs
        if done:
            self.stop_robot(); self.log_episode()
            self.get_logger().info(f"EP {self.episode} terminado. steps={self.step} return={self.ep_rewards:.3f}")
            self.episode += 1; self.step = 0; self.ep_rewards = 0.0; self.prev_obs = None
            self.maybe_randomize_goal(); time.sleep(0.5)
            self.get_logger().info(f"EP {self.episode} iniciado.")

def main():
    rclpy.init()
    node = RLLoggerROS2()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop_robot(); node.destroy_node(); rclpy.shutdown()

if __name__ == '__main__':
    main()
